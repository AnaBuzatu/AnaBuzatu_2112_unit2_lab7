function myFunction() {
  document.getElementById("demo").innerHTML = "CEO";
  document.getElementById("poza").src="etti.png";
  var tabel=document.getElementById("tabel");
	tabel.rows[0].cells[0].innerHTML="Bursa";
	tabel.rows[0].cells[1].innerHTML="Prieteni";
	tabel.rows[0].cells[2].innerHTML="Note mari";
	tabel.rows[1].cells[0].innerHTML="BEST";
	tabel.rows[1].cells[1].innerHTML="Fara restante";
	tabel.rows[1].cells[2].innerHTML="Nota 10";
	tabel.rows[2].cells[0].innerHTML="Un job satisfacator";
	tabel.rows[2].cells[1].innerHTML="Bursa";
	tabel.rows[2].cells[2].innerHTML="Bursa";
	tabel.rows[3].cells[0].innerHTML="Bursa";
	tabel.rows[3].cells[1].innerHTML="Bursa";
	tabel.rows[3].cells[2].innerHTML="Bursa";
 
	document.body.style.background ="#e6ccff";
	
	
	var par=document.getElementByTagName("p");
	var i;
		for(i=0;i<par.length;i++){
		par[i].style.color="#8c1aff";
		}
	

	document.getElementById("poza").style.opacity = "0.8";
	document.getElementById("font").style.border = "8px";
		
}

function Varsta()
{
	var azi=new Date;
	var varstaMea;
	var an=document.getElementById("varsta").innerHTML;
	varstaMea=azi.getFullYear()-parseInt(an);
	document.getElementById("varsta").innerHTML=varstaMea;
}
